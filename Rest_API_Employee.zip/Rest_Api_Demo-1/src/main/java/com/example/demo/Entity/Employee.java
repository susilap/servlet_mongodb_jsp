package com.example.demo.Entity;
import jakarta.persistence.*;

@Entity
@Table(name="employees")
public class Employee 
{
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private long id;

@Column(name="name")
private String name;

@Column(name="dept")
private String dept;

@Column(name="salary")
private long salary;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDept() {
	return dept;
}

public void setDept(String dept) {
	this.dept = dept;
}

public long getSalary() {
	return salary;
}

public void setSalary(long salary) {
	this.salary = salary;
}


}
