package Hibernate_Demo_mongodb.Hibernate_Demo_mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateDemoMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
