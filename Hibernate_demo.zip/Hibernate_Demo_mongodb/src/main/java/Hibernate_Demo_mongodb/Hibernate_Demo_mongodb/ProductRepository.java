package Hibernate_Demo_mongodb.Hibernate_Demo_mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;


public interface ProductRepository extends MongoRepository < Product, Long >{

}
