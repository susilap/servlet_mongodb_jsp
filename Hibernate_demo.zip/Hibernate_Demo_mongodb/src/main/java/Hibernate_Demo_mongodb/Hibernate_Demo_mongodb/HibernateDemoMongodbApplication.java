package Hibernate_Demo_mongodb.Hibernate_Demo_mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateDemoMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateDemoMongodbApplication.class, args);
	}

}
