$(document).ready(function() {
	$('#login_id, #login_pwd').click(function() {	    		
		$("#errMsg").hide();
	});
});