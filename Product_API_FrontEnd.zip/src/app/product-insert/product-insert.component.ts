import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-insert',
  templateUrl: './product-insert.component.html',
  styleUrls: ['./product-insert.component.css']
})
export class ProductInsertComponent implements OnInit {

  product : Product = new Product();
  constructor(private productService:ProductService,private router:Router) { }
  saveProduct()
  {
    this.productService.createProduct(this.product).subscribe(data=>{console.log(data);
    this.goToProductList();},error=>console.log(error));
  }
  goToProductList()
  {
    this.router.navigate(['/products']);
  }
  onSubmit()
  {
    console.log(this.product);
    this.saveProduct();
  }
  ngOnInit(): void {
  }

}
