import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Product } from './product';
import { Observable,throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService
 {
   private baseUrl="http://localhost:8080/products";
   
  constructor(private httpClient:HttpClient) { }

  getProductList():Observable<Product[]>{
    return this.httpClient.get<Product[]>(`${this.baseUrl}`);
  }
  getProductById(id:number):Observable<Product>{
    return this.httpClient.get<Product>(`${this.baseUrl}`);
  }

  updateProduct(id:number,product:Product):Observable<Object>{
    return this.httpClient.put(`${this.baseUrl}/${id}`,product);
  }
  deleteProduct(id:number):Observable<object>{
    return this.httpClient.delete(`${this.baseUrl}/${id}`);
  }

  createProduct(product:Product):Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`,product);
  }
}
